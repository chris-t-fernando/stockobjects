from stockobjects.company import Company

class CompanyCollection():
    def __init__(self):
        ...

    def get_quotes(self):
        return False

    def add_company(self):
        return False

    